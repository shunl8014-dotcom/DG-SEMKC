function [Hstar, beta, obj, Ztemp] = DGSEMKC(H, k, lambda1, lambda2, lambda3, L, N, V)
for p = 1:V
    [Q, ~] = qr(H{p}, 0);  %保证H_p^T H_p = I
    H{p} = Q;
end
num = N;          % 样本数量
numker = V;       % 核数量
maxIter = 30;     % 最大迭代次数
obj = zeros(maxIter, 1);  
Z = eye(num);    
beta = ones(V, 1)/V;     
opt.disp = 0;
HHT = cell(numker, 1);
for p = 1:numker
    HHT{p} = H{p} * H{p}';
end
flag = 1;
iter = 0;
while flag
    iter = iter + 1;   
    %计算A
    A = zeros(num, num);
    for p = 1:numker
        A = A + beta(p)^2 * HHT{p}; 
    end    
    %计算S
    S = zeros(num, num);
    for p = 1:numker
        dist_mat = pdist2(H{p}, H{p}, 'euclidean').^2;
        S = S + dist_mat;
    end
    S = (lambda2 / 2) * S;    
    G = 2 * Z * A - 2 * A + 2 * lambda1 * Z + S + 2 * lambda3 * Z * L;  
    Hessian_bound = 2 * (A + lambda1 * eye(num) + lambda3 * L);
    mu = 1 / norm(Hessian_bound);     
    Z_hat = Z - mu * G;    
    Z_new = zeros(num, num); 
    for i = 1:num 
       idx = [1:i-1, i+1:num];    
       Z_new(i, idx) = EProjSimplex_new(Z_hat(i, idx));
    end
    Z = Z_new; 
    %
    M = zeros(V, 1);
    for p = 1:V
        M(p) = norm(H{p} - Z * H{p}, 'fro'); 
    end
    Mfra = M.^-2;      
    Q = 1 / sum(Mfra);    
    beta = Q * Mfra;           
    W1 = (Z + Z') / 2;               
    D1 = diag(sum(W1, 2));            
    L1 = D1 - W1;                       
    term1 = 0;
    for j = 1:numker
        term1 = term1 + beta(j)^2 * norm(H{j} - Z * H{j}, 'fro')^2; 
    end
    term2 = lambda1 * norm(Z, 'fro')^2;
    term3 = lambda3 * trace(Z * L * Z');
    term4 = 0;
    for j = 1:numker
        term4 = term4 + trace(H{j}' * L1 * H{j});
    end
    term4 = lambda2 * term4;
    obj(iter) = term1 + term2 + term3 + term4;    
    if (iter > 2) && (abs((obj(iter-1) - obj(iter)) / obj(iter-1)) < 1e-6 || iter > maxIter)
        Z = (Z + Z') / 2;     
        Ztemp = Z;
        [Hstar, ~] = eigs(Z, k, 'la', opt);  
        flag = 0;
    end
end
obj = obj(1:iter);
end
