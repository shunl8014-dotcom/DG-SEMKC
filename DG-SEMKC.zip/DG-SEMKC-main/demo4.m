close all; clear all; clc
warning off;
addpath(genpath('ClusteringMeasure'));
addpath(genpath('function'));

ResSavePath = 'Res/';
MaxResSavePath = 'maxRes/';
if ~exist(ResSavePath, 'dir'), mkdir(ResSavePath); end
if ~exist(MaxResSavePath, 'dir'), mkdir(MaxResSavePath); end

dataPath = 'D:\实验\DG-SEMKC-main\DG-SEMKC-main\datasets\';
datasetName = {'AR10P'}; 

for dataIndex = 1:length(datasetName)
    dataName = [dataPath datasetName{dataIndex} '_Kmatrix.mat'];
    load(dataName);  
    ResBest = zeros(1, 8);
    ResStd = zeros(1, 8);
    %% Data Preparation
    c = max(Y);
    V = size(KH, 3);
    N = size(KH, 1);
    KH = kcenter(KH);
    KH = knorm(KH);
    gamma0 = ones(V, 1) / V;
    avgKer = mycombFun(KH, gamma0);
    best_k = 7; 
    distMat = max(bsxfun(@plus, diag(avgKer), diag(avgKer)') - 2 * avgKer, 0);
    distMat = sqrt(distMat); 
    Adj = zeros(N, N);
    for i = 1:N
        [~, idx] = sort(distMat(i, :), 'ascend');
        Adj(i, idx(2:best_k+1)) = 1;
    end
    Adj = max(Adj, Adj');
    D = diag(sum(Adj, 2));
    L = D - Adj;  
    
    %% parameters setting
    r1_list = 0:2:4;
    r2_list = -4:2:4;
    r3_list = 0.01:0.01:0.09;
    r4_list = -4:2:2;
    
    acc = zeros(length(r1_list), length(r2_list), length(r3_list), length(r4_list));
    nmi = zeros(length(r1_list), length(r2_list), length(r3_list), length(r4_list));
    purity = zeros(length(r1_list), length(r2_list), length(r3_list), length(r4_list));
    idx = 1;
    
    for r1Index = 1:length(r1_list)
        r1Temp = r1_list(r1Index);
        lambda = 5^r1Temp;
        
        for r2Index = 1:length(r2_list)
            r2Temp = r2_list(r2Index);
            beta_param = 2^r2Temp;
            
            for r3Index = 1:length(r3_list)
                r3Temp = r3_list(r3Index);
                
                for r4Index = 1:length(r4_list)
                    r4Temp = r4_list(r4Index);
                    gamma_lap = 10^r4Temp;
                    
                    % initialize the dimension of each kernel partition
                    evs = zeros(V,N);
                    for i = 1:V
                        evs(i,:) = eigs(KH(:,:,i),N)';
                    end
                    esr = zeros(V,N);
                    for i = 1:V
                        for j = 1:N
                            temp = evs(i,:);
                            esr(i,j) = sum(temp(1:j))/sum(evs(i,:));
                        end
                    end
                    esry = zeros(V,N);
                    for i = 1:V
                        for j = 2:N
                            temp = esr(i,:);
                            esry(i,j) = (temp(j) - temp(j-1))/temp(j-1);
                        end
                    end
                    indexx = zeros(1,V);
                    for i = 1:V
                        for tempi = 1:(N-1)
                            temp = esry(i,:);
                            if (abs((temp(tempi)-temp(tempi+1))/temp(tempi)) < r3Temp)
                                break;
                            end
                        end
                        indexx(i) = tempi;
                    end     
                    
                    % Main algorithm
                    disp(['Dataset: ', datasetName{dataIndex}, ...
                        ', r1: ', num2str(r1Temp), ', r2: ', num2str(r2Temp), ...
                        ', r3: ', num2str(r3Temp), ', r4: ', num2str(r4Temp)]);
                    
                    F = cell(V, 1);
                    for i = 1:V
                        [F{i}] = mykernelkmeans(KH(:, :, i), indexx(i));
                    end
                   
                    [Fstar, mu_view, obj, Ztemp] = DGSEMKC(F, c, lambda, gamma_lap, beta_param, L, N, V);
         
                    [res] = myNMIACC(real(Fstar), Y, c);      
                    idx = idx + 1;
                    
                    tempResBest = res(1, :);
                    tempResStd = res(2, :);
                    
                    acc(r1Index, r2Index, r3Index, r4Index) = tempResBest(7);
                    nmi(r1Index, r2Index, r3Index, r4Index) = tempResBest(4);
                    purity(r1Index, r2Index, r3Index, r4Index) = tempResBest(8);
                    
                    resFile = [ResSavePath datasetName{dataIndex}, '-ACC=', num2str(tempResBest(7)), ...
                        '-r1=', num2str(r1Temp), '-r2=', num2str(r2Temp), ...
                        '-r3=', num2str(r3Temp), '-r4=', num2str(r4Temp), '.mat'];
                    save(resFile, 'tempResBest', 'tempResStd', 'F');
                    
                    for tempIndex = 1:8
                        if tempResBest(tempIndex) > ResBest(tempIndex)
                            if tempIndex == 7
                                newF = Fstar;
                                newgamma = mu_view;
                                newobj = obj;
                                newZ = Ztemp;
                            end
                            ResBest(tempIndex) = tempResBest(tempIndex);
                            ResStd(tempIndex) = tempResStd(tempIndex);
                        end
                    end
                end
            end
        end
    end
    resFile2 = [MaxResSavePath datasetName{dataIndex}, '-ACC=', num2str(ResBest(7)), '.mat'];
    save(resFile2, 'ResBest', 'ResStd', 'acc', 'nmi', 'purity', 'newF', 'newgamma', 'newobj', 'Y', 'newZ');  
end


